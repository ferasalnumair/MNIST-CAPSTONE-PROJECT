import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
# ==================================================
# Reproducibility
# ==================================================
np.random.seed(42)
tf.random.set_seed(42)
# ==================================================
# Dataset Path
# ==================================================
dataset_path = "extracted_data/ddddd/training_set"
# ==================================================
# Load Dataset
# ==================================================
train_ds = tf.keras.utils.image_dataset_from_directory(
    dataset_path,
    validation_split=0.2,
    subset="training",
    seed=42,
    image_size=(128, 128),
    batch_size=32
)
val_ds = tf.keras.utils.image_dataset_from_directory(
    dataset_path,
    validation_split=0.2,
    subset="validation",
    seed=42,
    image_size=(128, 128),
    batch_size=32
)
# ==================================================
# Optimize Performance
# ==================================================
AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.prefetch(buffer_size=AUTOTUNE)
# ==================================================
# Data Augmentation
# ==================================================
data_augmentation = tf.keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.1),
    layers.RandomZoom(0.1)
])
# ==================================================
# Build CNN Model
# ==================================================
model = models.Sequential([
    data_augmentation,
    layers.Rescaling(1./255),
    layers.Conv2D(32, (3,3), activation='relu'),
    layers.MaxPooling2D(),
    layers.Conv2D(64, (3,3), activation='relu'),
    layers.MaxPooling2D(),
    layers.Conv2D(128, (3,3), activation='relu'),
    layers.MaxPooling2D(),
    layers.Flatten(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(1, activation='sigmoid')
])
# ==================================================
# Compile Model
# ==================================================
model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)
# ==================================================
# Model Summary
# ==================================================
model.summary()
# ==================================================
# Train Model
# ==================================================
history = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=10
)
# ==================================================
# Create Folders
# ==================================================
os.makedirs("models", exist_ok=True)
os.makedirs("reports", exist_ok=True)
# ==================================================
# Save Model
# ==================================================
model.save("models/cats_dogs_cnn.h5")
# ==================================================
# Save Training Curve
# ==================================================
plt.figure(figsize=(8,5))
plt.plot(
    history.history['accuracy'],
    label='Training Accuracy'
)
plt.plot(
    history.history['val_accuracy'],
    label='Validation Accuracy'
)
plt.title("Training vs Validation Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.savefig("reports/training_curve.png")
plt.show()
# ==================================================
# Experiment Table
# ==================================================
experiment_table = pd.DataFrame({
    "Experiment": ["CNN + Dropout + Data Augmentation"],
    "Epochs": [10],
    "Batch Size": [32],
    "Best Validation Accuracy": [
        round(max(history.history['val_accuracy']) * 100, 2)
    ]
})
experiment_table.to_csv(
    "reports/experiment_table.csv",
    index=False
)
print("\nExperiment Table")
print(experiment_table)
print("\nPhase 2 Completed Successfully!")